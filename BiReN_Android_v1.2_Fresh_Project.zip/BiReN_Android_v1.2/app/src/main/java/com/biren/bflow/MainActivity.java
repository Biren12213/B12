
package com.biren.bflow;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    SharedPreferences sp;
    final String[] defaultCats = {"A - Food & Dining","B - Shopping","C - Transport","D - Bills & Utilities","E - Health","F - Education","G - Entertainment","H - Travel","I - Savings","J - Family","K - Others"};
    final double CAT_PCT = 100.0/11.0;
    String[] accounts = {"Account 1","Account 2","Account 3","Account 4","Account 5"};
    double[] balances = new double[5];
    double monthlyIncome=0;
    ArrayList<Tx> txs = new ArrayList<>();
    int green = Color.rgb(8,122,82), dark=Color.rgb(0,88,60), bg=Color.rgb(247,251,249), text=Color.rgb(20,33,28), muted=Color.rgb(109,122,117), red=Color.rgb(217,72,95), gold=Color.rgb(242,182,50);

    static class Tx {
        String type, cat, account, toAccount, note, date; double amount;
        Tx(String t,String c,String a,double x,String n,String d){type=t;cat=c;account=a;amount=x;note=n;date=d;}
        JSONObject json() throws Exception { JSONObject o=new JSONObject(); o.put("type",type);o.put("cat",cat);o.put("account",account);o.put("to",toAccount==null?"":toAccount);o.put("note",note);o.put("date",date);o.put("amount",amount);return o; }
        static Tx from(JSONObject o)throws Exception{Tx t=new Tx(o.optString("type"),o.optString("cat"),o.optString("account"),o.optDouble("amount"),o.optString("note"),o.optString("date"));t.toAccount=o.optString("to");return t;}
    }

    @Override public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("biren",0); load(); showSplash();}

    void load(){
        for(int i=0;i<5;i++){accounts[i]=sp.getString("acc"+i,accounts[i]);balances[i]=Double.longBitsToDouble(sp.getLong("bal"+i,Double.doubleToLongBits(0)));}
        monthlyIncome=Double.longBitsToDouble(sp.getLong("income",Double.doubleToLongBits(0)));
        try{JSONArray a=new JSONArray(sp.getString("txs","[]"));for(int i=0;i<a.length();i++)txs.add(Tx.from(a.getJSONObject(i)));}catch(Exception e){}
    }
    void save(){
        SharedPreferences.Editor e=sp.edit(); for(int i=0;i<5;i++){e.putString("acc"+i,accounts[i]);e.putLong("bal"+i,Double.doubleToLongBits(balances[i]));}
        e.putLong("income",Double.doubleToLongBits(monthlyIncome)); JSONArray a=new JSONArray();try{for(Tx t:txs)a.put(t.json());}catch(Exception x){} e.putString("txs",a.toString());e.apply();
    }
    String money(double x){return "₹"+String.format(Locale.US,"%,.0f",x);}
    TextView tv(String s,float sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(text);t.setPadding(18,12,18,12);return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    TextView card(String s){TextView t=tv(s,15);t.setBackground(bg(Color.WHITE,28));t.setElevation(2);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setBackground(bg(green,50));return b;}
    void base(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,14,18,12);sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(8,5,8,5);root.addView(nav,new LinearLayout.LayoutParams(-1,64));setContentView(root);
        TextView h=tv(title,25);h.setTypeface(null,1);content.addView(h);
        String[] ns={"Home","Accounts","+","Reports","More"};for(String n:ns){Button b=new Button(this);b.setText(n);b.setTextSize(12);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener(v->{if(n.equals("Home"))home();else if(n.equals("Accounts"))accountsScreen();else if(n.equals("Reports"))reports();else if(n.equals("More"))more();else quickMenu();});nav.addView(b,new LinearLayout.LayoutParams(0,64,1));}
    }
    void showSplash(){base("");content.setGravity(Gravity.CENTER);ImageView im=new ImageView(this);im.setImageResource(com.biren.bflow.R.drawable.biren_logo);im.setAdjustViewBounds(true);content.addView(im,new LinearLayout.LayoutParams(-1,420));TextView w=tv("BiReN",34);w.setGravity(Gravity.CENTER);w.setTypeface(null,1);content.addView(w);TextView sub=tv("Money Growth • Budget • Accounts",16);sub.setGravity(Gravity.CENTER);content.addView(sub);Button go=btn("Get Started →");go.setOnClickListener(v->home());content.addView(go,new LinearLayout.LayoutParams(-1,60));}

    void home(){
        base("Good Morning!");
        TextView hi=tv("Let's manage your money wisely.",14);hi.setTextColor(muted);content.addView(hi);
        TextView bal=card("TOTAL BALANCE (ALL 5 ACCOUNTS)\n"+money(totalBalance()));bal.setTextColor(Color.WHITE);bal.setTextSize(21);bal.setPadding(20,20,20,20);bal.setBackground(bg(green,30));content.addView(bal,new LinearLayout.LayoutParams(-1,110));
        LinearLayout row=new LinearLayout(this);String[] labels={"Monthly Income","Expenses","Remaining"};double exp=totalExpenses();double rem=totalBalance();for(int i=0;i<3;i++){TextView c=card(labels[i]+"\n"+money(i==0?monthlyIncome:i==1?exp:rem));c.setTextSize(14);row.addView(c,new LinearLayout.LayoutParams(0,90,1));}content.addView(row);
        TextView ah=tv("Accounts",19);ah.setTypeface(null,1);content.addView(ah);
        for(int i=0;i<5;i++){final int k=i;TextView c=card(accounts[i]+"\n"+money(balances[i]));c.setOnClickListener(v->accountDetail(k));content.addView(c,new LinearLayout.LayoutParams(-1,78));}
        TextView bh=tv("Budget Progress (A–K)",19);bh.setTypeface(null,1);content.addView(bh);
        double catSpent=0;for(Tx t:txs)if(t.type.equals("EXPENSE"))catSpent+=t.amount;double pct=monthlyIncome<=0?0:Math.min(100,catSpent/monthlyIncome*100);
        TextView prog=card(String.format(Locale.US,"%.0f%% of monthly income spent\nAllocated equally: %.2f%% per category",pct,CAT_PCT));content.addView(prog);
        Button add=btn("+ Add Expense / Income / Transfer");add.setOnClickListener(v->quickMenu());content.addView(add,new LinearLayout.LayoutParams(-1,58));
    }

    double totalBalance(){double x=0;for(double b:balances)x+=b;return x;}
    double totalExpenses(){double x=0;for(Tx t:txs)if(t.type.equals("EXPENSE"))x+=t.amount;return x;}

    void accountsScreen(){
        base("Accounts (5)");
        TextView info=tv("Edit account names, view balances, add money and transfer between accounts.",14);info.setTextColor(muted);content.addView(info);
        for(int i=0;i<5;i++){final int k=i;TextView c=card("💰  "+accounts[i]+"\n"+money(balances[i])+"    ✎");c.setOnClickListener(v->accountDetail(k));content.addView(c,new LinearLayout.LayoutParams(-1,82));}
        Button inc=btn("Enter Monthly Income & Allocate");inc.setOnClickListener(v->incomeDialog());content.addView(inc,new LinearLayout.LayoutParams(-1,58));
        Button tr=btn("Transfer Between Accounts");tr.setOnClickListener(v->transferDialog());content.addView(tr,new LinearLayout.LayoutParams(-1,58));
        TextView total=card("OVERALL BALANCE\n"+money(totalBalance()));total.setTextSize(19);total.setBackground(bg(Color.rgb(232,248,239),25));content.addView(total);
    }

    void accountDetail(int k){
        base(accounts[k]);
        TextView c=card("CURRENT BALANCE\n"+money(balances[k]));c.setTextSize(22);c.setBackground(bg(Color.rgb(232,248,239),28));content.addView(c);
        Button rn=btn("Edit Account Name");rn.setOnClickListener(v->renameDialog(k));content.addView(rn,new LinearLayout.LayoutParams(-1,58));
        Button ad=btn("Add Money");ad.setOnClickListener(v->addMoneyDialog(k));content.addView(ad,new LinearLayout.LayoutParams(-1,58));
        TextView h=tv("Recent Transactions",18);h.setTypeface(null,1);content.addView(h);
        int count=0;for(int i=txs.size()-1;i>=0&&count<12;i--){Tx t=txs.get(i);if(t.account.equals(accounts[k])){TextView x=card(t.type+" • "+(t.cat.length()>0?t.cat:t.toAccount)+"\n"+(t.type.equals("EXPENSE")?"-":"+")+money(t.amount));content.addView(x);count++;}}
    }

    void incomeDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,0,10,0);
        EditText income=new EditText(this);income.setHint("Monthly income");income.setInputType(2|8192);box.addView(income);
        EditText[] e=new EditText[5];for(int i=0;i<5;i++){e[i]=new EditText(this);e[i].setHint(accounts[i]+" amount");e[i].setInputType(2|8192);box.addView(e[i]);}
        new AlertDialog.Builder(this).setTitle("Monthly Income → 5 Accounts").setMessage("Enter income and how much should be added to each account. Unallocated income is allowed.").setView(box).setPositiveButton("Save",(d,w)->{double inc=num(income);monthlyIncome=inc;for(int i=0;i<5;i++){double a=num(e[i]);balances[i]+=a;if(a>0)txs.add(new Tx("INCOME","",accounts[i],a,"Monthly income allocation",date()));}save();home();}).setNegativeButton("Cancel",null).show();
    }
    void addMoneyDialog(int k){
        EditText e=new EditText(this);e.setHint("Amount");e.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Add Money to "+accounts[k]).setView(e).setPositiveButton("Add",(d,w)->{double a=num(e);if(a>0){balances[k]+=a;txs.add(new Tx("INCOME","",accounts[k],a,"Add money",date()));save();accountDetail(k);}}).setNegativeButton("Cancel",null).show();
    }
    void renameDialog(int k){
        EditText e=new EditText(this);e.setText(accounts[k]);new AlertDialog.Builder(this).setTitle("Edit Account Name").setView(e).setPositiveButton("Save",(d,w)->{String n=e.getText().toString().trim();if(!n.isEmpty()){accounts[k]=n;for(Tx t:txs){if(t.account.equals(accounts[k])){} }save();accountsScreen();}}).setNegativeButton("Cancel",null).show();
    }
    void transferDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);Spinner from=new Spinner(this),to=new Spinner(this);String[] names=accounts.clone();from.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));to.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));EditText amt=new EditText(this);amt.setHint("Amount");amt.setInputType(2|8192);box.addView(from);box.addView(to);box.addView(amt);
        new AlertDialog.Builder(this).setTitle("Transfer Money").setView(box).setPositiveButton("Transfer",(d,w)->{int f=from.getSelectedItemPosition(),t=to.getSelectedItemPosition();double a=num(amt);if(f!=t&&a>0&&a<=balances[f]){balances[f]-=a;balances[t]+=a;Tx x=new Tx("TRANSFER","",accounts[f],a,"Transfer",date());x.toAccount=accounts[t];txs.add(x);save();accountsScreen();}}).setNegativeButton("Cancel",null).show();
    }
    void quickMenu(){
        final String[] x={"Add Expense","Add Income","Transfer Money","Monthly Income & Allocation"};new AlertDialog.Builder(this).setTitle("Quick Action").setItems(x,(d,w)->{if(w==0)expenseDialog();else if(w==1)incomeToOneDialog();else if(w==2)transferDialog();else incomeDialog();}).show();
    }
    void expenseDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText amt=new EditText(this);amt.setHint("Amount");amt.setInputType(2|8192);box.addView(amt);
        Spinner cat=new Spinner(this);cat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,defaultCats));box.addView(cat);
        Spinner acc=new Spinner(this);acc.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,accounts));box.addView(acc);
        EditText note=new EditText(this);note.setHint("Note (optional)");box.addView(note);
        new AlertDialog.Builder(this).setTitle("Add Expense").setView(box).setPositiveButton("Save",(d,w)->{double a=num(amt);int k=acc.getSelectedItemPosition();if(a>0&&a<=balances[k]){balances[k]-=a;txs.add(new Tx("EXPENSE",defaultCats[cat.getSelectedItemPosition()],accounts[k],a,note.getText().toString(),date()));save();home();}}).setNegativeButton("Cancel",null).show();
    }
    void incomeToOneDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText amt=new EditText(this);amt.setHint("Amount");amt.setInputType(2|8192);box.addView(amt);Spinner acc=new Spinner(this);acc.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,accounts));box.addView(acc);
        new AlertDialog.Builder(this).setTitle("Add Income to Account").setView(box).setPositiveButton("Save",(d,w)->{double a=num(amt);int k=acc.getSelectedItemPosition();if(a>0){balances[k]+=a;monthlyIncome+=a;txs.add(new Tx("INCOME","",accounts[k],a,"Income",date()));save();home();}}).setNegativeButton("Cancel",null).show();
    }
    void reports(){
        base("Reports / Statistics");
        TextView t=card("Monthly Income\n"+money(monthlyIncome)+"\n\nTotal Expenses\n"+money(totalExpenses())+"\n\nOverall Balance\n"+money(totalBalance()));t.setTextSize(18);content.addView(t);
        TextView h=tv("Account-wise",18);h.setTypeface(null,1);content.addView(h);for(int i=0;i<5;i++)content.addView(card(accounts[i]+"  •  "+money(balances[i])));
        TextView c=tv("Category allocation is equal at 9.09% of monthly income. Expenses reduce both the selected account and selected category budget.",14);c.setTextColor(muted);content.addView(c);
    }
    void more(){
        base("More / Settings");
        String[] a={"Manage Accounts (5)","Manage Categories (A–K)","Monthly Budget","Reports","Backup / Restore","Export Data","Settings","About BiReN v1.2"};
        for(String s:a){Button b=btn(s);content.addView(b,new LinearLayout.LayoutParams(-1,58));if(s.startsWith("Manage Accounts"))b.setOnClickListener(v->accountsScreen());else if(s.equals("Reports"))b.setOnClickListener(v->reports());else if(s.startsWith("Monthly"))b.setOnClickListener(v->budgetScreen());else if(s.startsWith("Manage Categories"))b.setOnClickListener(v->categoriesScreen());else if(s.startsWith("Export"))b.setOnClickListener(v->exportDialog());}
    }
    void budgetScreen(){
        base("Monthly Budget");
        TextView top=card("MONTHLY INCOME\n"+money(monthlyIncome)+"\n\nEqual category allocation: "+String.format(Locale.US,"%.2f%%",CAT_PCT));top.setTextSize(18);content.addView(top);
        for(String c:defaultCats){double alloc=monthlyIncome/11.0, spent=0;for(Tx t:txs)if(t.type.equals("EXPENSE")&&t.cat.equals(c))spent+=t.amount;double rem=alloc-spent;content.addView(card(c+"\nAllocation "+money(alloc)+"   •   Spent "+money(spent)+"   •   Remaining "+money(rem)));}
    }
    void categoriesScreen(){base("Categories (A–K)");for(String c:defaultCats){TextView t=card(c+"\n9.09% of monthly income");content.addView(t);}}
    void exportDialog(){new AlertDialog.Builder(this).setTitle("Backup / Export").setMessage("Local data is stored on this device. v1.2 keeps accounts, balances, income and transaction history in local storage. Full file export can be added to the release build.").setPositiveButton("OK",null).show();}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    String date(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
}
