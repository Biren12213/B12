# BiReN / BFlow Android v1.2

Fresh Android project for the second updated budget-tracker version.

## Included
- Modern BiReN money-growth branding.
- 5 editable accounts.
- Account-wise and overall balances.
- Monthly income allocation across accounts.
- Expense account selection.
- Account-to-account transfers.
- A–K equal category budget (9.09% each).
- Category expense tracking.
- Monthly budget and reports screens.
- Local/offline persistence with SharedPreferences.
- Android version 1.2.

## Build
The GitHub Actions workflow should use Android Gradle Plugin 8.7.3 and Java 17.
