# BiReN / BFlow Android v1.2

Fresh Android project for the second updated budget-tracker version with a full UI redesign.

## Included
- Modern BiReN money-growth branding.
- 5 editable accounts.
- Account-wise and overall balances.
- Monthly income allocation across accounts.
- Expense account selection.
- Account-to-account transfers.
- A–K equal category budget (9.09% each).
- Category expense tracking.
- Monthly budget and reports screens.
- Local/offline persistence with SharedPreferences.
- Android version 1.2.

## Build
The GitHub Actions workflow should use Android Gradle Plugin 8.7.3 and Java 17.

## UI fix build
This build adds Android system-bar insets and larger/wrapped controls so the status bar, cards, action button, and bottom navigation are not clipped.


## UI redesign
- Safe status/navigation bar handling for modern Android.
- Card-based dashboard matching the approved visual direction.
- Fixed bottom navigation with Home, Accounts, Add, Reports, More.
- Improved account cards, budget cards, transaction cards, and spacing.
